# Notifications

Notification retrieval operations

```php
$notificationsApi = $client->getNotificationsApi();
```

## Class Name

`NotificationsApi`


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```php
function getPopupNotifications(string $useridto, int $limit, int $offset): ApiResponse
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `string` | Query, Required | ID of the recipient user (yourself), passed as a string. Get your numeric user ID from `GET /service/core_webservice_get_site_info`. |
| `limit` | `int` | Query, Required | Maximum number of notifications to return. |
| `offset` | `int` | Query, Required | Pagination offset. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`PopupNotificationsResponse`](../../doc/models/popup-notifications-response.md).

## Example Usage

```php
$useridto = 'useridto2';

$limit = 172;

$offset = 0;

$notificationsApi = $client->getNotificationsApi();
$apiResponse = $notificationsApi->getPopupNotifications(
    $useridto,
    $limit,
    $offset
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'PopupNotificationsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

