# Notifications

Notification retrieval operations

```csharp
NotificationsApi notificationsApi = client.NotificationsApi;
```

## Class Name

`NotificationsApi`

## Methods

* [Fetch Notifications](../../doc/controllers/notifications.md#fetch-notifications)
* [Get Popup Notifications](../../doc/controllers/notifications.md#get-popup-notifications)


# Fetch Notifications

Returns pending site-level notifications for the given Moodle context. Returns an empty array when there are no pending notifications.
Moodle method: `core_fetch_notifications`

```csharp
FetchNotificationsAsync(
    int contextid)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contextid` | `int` | Query, Required | Moodle context ID for which to fetch notifications. The user context ID can be found in the user profile image URL path segment. |

## Response Type

**200**: Array of site notifications (empty array when none are pending).

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.SiteNotification>](../../doc/models/site-notification.md).

## Example Usage

```csharp
int contextid = 156;
try
{
    ApiResponse<List<SiteNotification>> result = await notificationsApi.FetchNotificationsAsync(contextid);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```csharp
GetPopupNotificationsAsync(
    string useridto,
    int limit,
    int offset)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `string` | Query, Required | ID of the recipient user, passed as a string. |
| `limit` | `int` | Query, Required | Maximum number of notifications to return. |
| `offset` | `int` | Query, Required | Pagination offset. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.PopupNotificationsResponse](../../doc/models/popup-notifications-response.md).

## Example Usage

```csharp
string useridto = "useridto2";
int limit = 172;
int offset = 0;
try
{
    ApiResponse<PopupNotificationsResponse> result = await notificationsApi.GetPopupNotificationsAsync(
        useridto,
        limit,
        offset
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

