# Calendar

Calendar operations. On NUST LMS, these "action events" are how deadlines are surfaced — assignment, lab, quiz, and other submission due dates each appear as a calendar event on the day the work must be submitted.

```csharp
CalendarApi calendarApi = client.CalendarApi;
```

## Class Name

`CalendarApi`

## Methods

* [Get Calendar Events by Timesort](../../doc/controllers/calendar.md#get-calendar-events-by-timesort)
* [Get Calendar Events by Course](../../doc/controllers/calendar.md#get-calendar-events-by-course)


# Get Calendar Events by Timesort

Returns action events (deadlines) across all enrolled courses, ordered by their sort timestamp. On NUST LMS these are submission due dates for assignments, labs, quizzes, and similar dated activities. Use `timesortfrom` to filter to upcoming deadlines only.
Moodle method: `core_calendar_get_action_events_by_timesort`

```csharp
GetCalendarEventsByTimesortAsync(
    int limitnum,
    int timesortfrom,
    int? timesortto = null,
    int? aftereventid = null)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limitnum` | `int` | Query, Required | Maximum number of events to return. |
| `timesortfrom` | `int` | Query, Required | Only return events with timesort >= this Unix timestamp. Pass 0 for no lower bound. |
| `timesortto` | `int?` | Query, Optional | Only return events with timesort <= this Unix timestamp. |
| `aftereventid` | `int?` | Query, Optional | Return events whose ID is greater than this value (cursor pagination). |

## Response Type

**200**: Calendar events sorted by timesort.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.CalendarEventsResponse](../../doc/models/calendar-events-response.md).

## Example Usage

```csharp
int limitnum = 32;
int timesortfrom = 58;
try
{
    ApiResponse<CalendarEventsResponse> result = await calendarApi.GetCalendarEventsByTimesortAsync(
        limitnum,
        timesortfrom
    );
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Calendar Events by Course

Returns all action events (deadlines) for a single course — assignment, lab, and quiz submission due dates, and other dated activities.
Moodle method: `core_calendar_get_action_events_by_course`

```csharp
GetCalendarEventsByCourseAsync(
    int courseid,
    int? timesortfrom = null,
    int? timesortto = null,
    int? aftereventid = null,
    int? limitnum = null)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `courseid` | `int` | Query, Required | ID of the course to fetch events for. |
| `timesortfrom` | `int?` | Query, Optional | Only return events with timesort >= this Unix timestamp. |
| `timesortto` | `int?` | Query, Optional | Only return events with timesort <= this Unix timestamp. |
| `aftereventid` | `int?` | Query, Optional | Cursor-based pagination — return events after this event ID. |
| `limitnum` | `int?` | Query, Optional | Maximum number of events to return. |

## Response Type

**200**: Calendar events for the specified course.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.CalendarEventsResponse](../../doc/models/calendar-events-response.md).

## Example Usage

```csharp
int courseid = 74;
try
{
    ApiResponse<CalendarEventsResponse> result = await calendarApi.GetCalendarEventsByCourseAsync(courseid);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

