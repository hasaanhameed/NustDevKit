
# Auth Login 401 Error Exception

*This model accepts additional fields of type object.*

## Structure

`AuthLogin401ErrorException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Detail` | `string` | Optional | - |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
try
{
    // make the API call
}
catch (ApiException e)
{
    if (e is AuthLogin401ErrorException)
    {
        // TODO: Handle AuthLogin401ErrorException
        Console.WriteLine(e.Message);
    }
}
```

