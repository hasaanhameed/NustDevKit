
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `Fullname` |
| `Shortname` |
| `Id` |
| `Idnumber` |
| `Timeaccess` |

## Example

```csharp
using NustLmsApi.Standard.Models;

CourseTimelineSortField courseTimelineSortField = CourseTimelineSortField.Fullname;
```

