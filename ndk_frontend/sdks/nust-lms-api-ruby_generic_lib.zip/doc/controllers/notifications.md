# Notifications

Notification retrieval operations

```ruby
notifications_api = client.notifications
```

## Class Name

`NotificationsApi`


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```ruby
def get_popup_notifications(useridto,
                            limit,
                            offset)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `String` | Query, Required | ID of the recipient user (yourself), passed as a string. Get your numeric user ID from `GET /service/core_webservice_get_site_info`. |
| `limit` | `Integer` | Query, Required | Maximum number of notifications to return. |
| `offset` | `Integer` | Query, Required | Pagination offset. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`PopupNotificationsResponse`](../../doc/models/popup-notifications-response.md).

## Example Usage

```ruby
useridto = 'useridto2'

limit = 172

offset = 0

result = notifications_api.get_popup_notifications(
  useridto,
  limit,
  offset
)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

