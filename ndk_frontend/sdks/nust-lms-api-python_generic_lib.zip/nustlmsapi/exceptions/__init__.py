# ruff: noqa: D104 | Missing docstring in public package
# ruff: noqa: RUF022 | `__all__` is not sorted
__all__ = [
    "api_exception",
    "auth_login_401_error_exception",
    "moodle_error_exception",
]
