
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `ID` |
| `IDNUMBER` |
| `USERNAME` |
| `EMAIL` |

## Example

```python
from nustlmsapi.models.user_profile_field import UserProfileField

user_profile_field = UserProfileField.USERNAME
```

