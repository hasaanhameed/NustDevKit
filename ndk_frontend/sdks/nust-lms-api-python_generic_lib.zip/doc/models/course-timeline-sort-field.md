
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `FULLNAME` |
| `SHORTNAME` |
| `ID` |
| `IDNUMBER` |
| `TIMEACCESS` |

## Example

```python
from nustlmsapi.models.course_timeline_sort_field import CourseTimelineSortField

course_timeline_sort_field = CourseTimelineSortField.FULLNAME
```

