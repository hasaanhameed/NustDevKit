
# Get Popup Notifications Request

Request parameters for retrieving popup notifications for a user.

*This model accepts additional fields of type Any.*

## Structure

`GetPopupNotificationsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `str` | Required | ID of the recipient user, passed as a string. |
| `limit` | `int` | Required | Maximum number of notifications to return. |
| `offset` | `int` | Required | Pagination offset.<br><br>**Default**: `0` |
| `additional_properties` | `Dict[str, Any]` | Optional | - |

## Example

```python
import jsonpickle

from nustlmsapi.models.get_popup_notifications_request import GetPopupNotificationsRequest

get_popup_notifications_request = GetPopupNotificationsRequest(
    useridto='123456',
    limit=20,
    offset=0,
    additional_properties={
        'exampleAdditionalProperty': jsonpickle.decode('{"key1":"val1","key2":"val2"}')
    }
)
```

