
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `ALL` |
| `INPROGRESS` |
| `PAST` |
| `FUTURE` |
| `FAVOURITES` |
| `HIDDEN` |
| `ALLINCLUDINGHIDDEN` |

## Example

```python
from nustlmsapi.models.course_timeline_classification import CourseTimelineClassification

course_timeline_classification = CourseTimelineClassification.FAVOURITES
```

