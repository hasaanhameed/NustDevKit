
# HttpConfiguration

The following parameters are configurable for the HttpConfiguration:

## Properties

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| timeout | `float64` | Timeout in seconds.<br>*Default*: `30` | `WithTimeout` | `Timeout()` |
| transport | `httpRoundTripper` | Establishes network connection and caches them for reuse.<br>*Default*: `http.DefaultTransport` | `WithTransport` | `Transport()` |
| retryConfiguration | [`nustLmsApiRetryConfiguration`](../doc/retry-configuration.md) | Configurations to retry requests.<br>*Default*: `nustLmsApi.DefaultRetryConfiguration()` | `WithRetryConfiguration` | `RetryConfiguration()` |

The httpConfiguration can be initialized as follows:

```go
package main

import (
    "nustLmsApi"
    "net/http"
)

func main() {
    httpConfiguration := nustLmsApi.CreateHttpConfiguration(
        nustLmsApi.WithTimeout(30),
        nustLmsApi.WithTransport(http.DefaultTransport),
        nustLmsApi.WithRetryConfiguration(nustLmsApi.DefaultRetryConfiguration()),
    )
}
```

