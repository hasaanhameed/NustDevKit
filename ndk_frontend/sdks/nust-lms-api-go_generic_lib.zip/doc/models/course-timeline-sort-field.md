
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `Fullname` |
| `Shortname` |
| `Id` |
| `Idnumber` |
| `Timeaccess` |

## Example

```go
package main

import (
    "nustLmsApi/models"
)

func main() {
    courseTimelineSortField := models.CourseTimelineSortField_Fullname

}
```

