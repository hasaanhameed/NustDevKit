# Notifications

Notification retrieval operations

```go
notificationsApi := client.NotificationsApi()
```

## Class Name

`NotificationsApi`


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```go
GetPopupNotifications(
    ctx context.Context,
    useridto string,
    limit int,
    offset int) (
    models.ApiResponse[models.PopupNotificationsResponse],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `string` | Query, Required | ID of the recipient user (yourself), passed as a string. Get your numeric user ID from `GET /service/core_webservice_get_site_info`. |
| `limit` | `int` | Query, Required | Maximum number of notifications to return. |
| `offset` | `int` | Query, Required | Pagination offset. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.PopupNotificationsResponse](../../doc/models/popup-notifications-response.md).

## Example Usage

```go
ctx := context.Background()

useridto := "useridto2"

limit := 172

offset := 0

apiResponse, err := notificationsApi.GetPopupNotifications(ctx, useridto, limit, offset)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

