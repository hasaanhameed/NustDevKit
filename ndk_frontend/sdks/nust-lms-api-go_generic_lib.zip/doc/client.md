
# Client Class Documentation

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| httpConfiguration | [`HttpConfiguration`](../doc/http-configuration.md) | Configurable http client options like timeout and retries. |
| loggerConfiguration | [`LoggerConfiguration`](../doc/logger-configuration.md) | Represents the logger configurations for API calls |
| bearerAuthCredentials | [`BearerAuthCredentials`](auth/oauth-2-bearer-token.md) | The Credentials Setter for OAuth 2 Bearer token |

The API client can be initialized as follows:

```go
package main

import (
    "nustLmsApi"
)

func main() {
    client := nustLmsApi.NewClient(
    nustLmsApi.CreateConfiguration(
            nustLmsApi.WithHttpConfiguration(
                nustLmsApi.CreateHttpConfiguration(
                    nustLmsApi.WithTimeout(30),
                ),
            ),
            nustLmsApi.WithBearerAuthCredentials(
                nustLmsApi.NewBearerAuthCredentials("AccessToken"),
            ),
            nustLmsApi.WithLoggerConfiguration(
                nustLmsApi.WithLevel("info"),
                nustLmsApi.WithRequestConfiguration(
                    nustLmsApi.WithRequestBody(true),
                ),
                nustLmsApi.WithResponseConfiguration(
                    nustLmsApi.WithResponseHeaders(true),
                ),
            ),
        ),
    )
}
```

## NUST LMS API Client

The gateway for the SDK. This class acts as a factory for the Apis and also holds the configuration of the SDK.

## Apis

| Name | Description |
|  --- | --- |
| AuthenticationApi() | Gets AuthenticationApi |
| CoursesApi() | Gets CoursesApi |
| CalendarApi() | Gets CalendarApi |
| AccountApi() | Gets AccountApi |
| NotificationsApi() | Gets NotificationsApi |

