# Notifications

Notification retrieval operations

```java
NotificationsApi notificationsApi = client.getNotificationsApi();
```

## Class Name

`NotificationsApi`

## Methods

* [Fetch Notifications](../../doc/controllers/notifications.md#fetch-notifications)
* [Get Popup Notifications](../../doc/controllers/notifications.md#get-popup-notifications)


# Fetch Notifications

Returns pending site-level notifications for the given Moodle context. Returns an empty array when there are no pending notifications.
Moodle method: `core_fetch_notifications`

```java
CompletableFuture<ApiResponse<List<SiteNotification>>> fetchNotificationsAsync(
    final int contextid)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contextid` | `int` | Query, Required | Moodle context ID for which to fetch notifications. The user context ID can be found in the user profile image URL path segment. |

## Response Type

**200**: Array of site notifications (empty array when none are pending).

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`List<SiteNotification>`](../../doc/models/site-notification.md).

## Example Usage

```java
int contextid = 156;

notificationsApi.fetchNotificationsAsync(contextid).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof MoodleErrorException) {
        MoodleErrorException moodleErrorException = (MoodleErrorException) cause;
        moodleErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```java
CompletableFuture<ApiResponse<PopupNotificationsResponse>> getPopupNotificationsAsync(
    final String useridto,
    final int limit,
    final int offset)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `String` | Query, Required | ID of the recipient user, passed as a string. |
| `limit` | `int` | Query, Required | Maximum number of notifications to return. |
| `offset` | `int` | Query, Required | Pagination offset. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PopupNotificationsResponse`](../../doc/models/popup-notifications-response.md).

## Example Usage

```java
String useridto = "useridto2";
int limit = 172;
int offset = 0;

notificationsApi.getPopupNotificationsAsync(useridto, limit, offset).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof MoodleErrorException) {
        MoodleErrorException moodleErrorException = (MoodleErrorException) cause;
        moodleErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

