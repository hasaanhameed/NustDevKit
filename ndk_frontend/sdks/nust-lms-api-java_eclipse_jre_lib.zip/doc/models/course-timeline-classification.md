
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `ALL` |
| `INPROGRESS` |
| `PAST` |
| `FUTURE` |
| `FAVOURITES` |
| `HIDDEN` |
| `ALLINCLUDINGHIDDEN` |

## Example

```java
import com.nustdevkit.api.models.CourseTimelineClassification;

CourseTimelineClassification courseTimelineClassification = CourseTimelineClassification.FUTURE;
```

