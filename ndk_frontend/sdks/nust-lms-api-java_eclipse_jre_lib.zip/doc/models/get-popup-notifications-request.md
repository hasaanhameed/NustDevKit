
# Get Popup Notifications Request

Request parameters for retrieving popup notifications for a user.

*This model accepts additional fields of type Object.*

## Structure

`GetPopupNotificationsRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Useridto` | `String` | Required | ID of the recipient user, passed as a string. | String getUseridto() | setUseridto(String useridto) |
| `Limit` | `int` | Required | Maximum number of notifications to return. | int getLimit() | setLimit(int limit) |
| `Offset` | `int` | Required | Pagination offset.<br><br>**Default**: `0` | int getOffset() | setOffset(int offset) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import java.io.IOException;
import m18000.m0.m0.m127.ApiHelper;
import m18000.m0.m0.m127.models.GetPopupNotificationsRequest;

GetPopupNotificationsRequest getPopupNotificationsRequest = new GetPopupNotificationsRequest.Builder(
    "123456",
    20,
    0
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

