# Users

User profile and preferences operations

```ts
const usersApi = new UsersApi(client);
```

## Class Name

`UsersApi`

## Methods

* [Get Users by Field](../../doc/controllers/users.md#get-users-by-field)
* [Get User Preferences](../../doc/controllers/users.md#get-user-preferences)


# Get Users by Field

Retrieves one or more user profiles by matching a specific profile field. Commonly used to look up the authenticated user's own profile by their ID.
Moodle method: `core_user_get_users_by_field`

```ts
async getUsersByField(
  field: UserProfileField,
  values: string[],
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserProfile[]>>
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | [`UserProfileField`](../../doc/models/user-profile-field.md) | Query, Required | User profile field to match against when searching for users. |
| `values` | `string[]` | Query, Required | List of field values to look up. All values must be provided as strings even when the field is numeric (e.g., "123456" for an integer ID). |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: List of matching user profiles.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`UserProfile[]`](../../doc/models/user-profile.md).

## Example Usage

```ts
const field = UserProfileField.Id;

const values: string[] = [
  'values0',
  'values1',
  'values2'
];

try {
  const response = await usersApi.getUsersByField(
    field,
    values
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |


# Get User Preferences

Returns all stored preference key/value pairs for the specified user. Optionally filter to a single preference by name.
Moodle method: `core_user_get_user_preferences`

```ts
async getUserPreferences(
  userid: number,
  name?: string,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserPreferencesResponse>>
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userid` | `number` | Query, Required | ID of the user whose preferences to retrieve. |
| `name` | `string \| undefined` | Query, Optional | Specific preference name to retrieve. Omit to retrieve all preferences. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: User preferences list and optional warnings.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`UserPreferencesResponse`](../../doc/models/user-preferences-response.md).

## Example Usage

```ts
const userid = 44;

try {
  const response = await usersApi.getUserPreferences(userid);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |

