# Notifications

Notification retrieval operations

```ts
const notificationsApi = new NotificationsApi(client);
```

## Class Name

`NotificationsApi`

## Methods

* [Fetch Notifications](../../doc/controllers/notifications.md#fetch-notifications)
* [Get Popup Notifications](../../doc/controllers/notifications.md#get-popup-notifications)


# Fetch Notifications

Returns pending site-level notifications for the given Moodle context. Returns an empty array when there are no pending notifications.
Moodle method: `core_fetch_notifications`

```ts
async fetchNotifications(
  contextid: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<SiteNotification[]>>
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contextid` | `number` | Query, Required | Moodle context ID for which to fetch notifications. The user context ID can be found in the user profile image URL path segment. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Array of site notifications (empty array when none are pending).

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`SiteNotification[]`](../../doc/models/site-notification.md).

## Example Usage

```ts
const contextid = 156;

try {
  const response = await notificationsApi.fetchNotifications(contextid);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```ts
async getPopupNotifications(
  useridto: string,
  limit: number,
  offset: number,
  requestOptions?: RequestOptions
): Promise<ApiResponse<PopupNotificationsResponse>>
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `useridto` | `string` | Query, Required | ID of the recipient user, passed as a string. |
| `limit` | `number` | Query, Required | Maximum number of notifications to return. |
| `offset` | `number` | Query, Required | Pagination offset. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`PopupNotificationsResponse`](../../doc/models/popup-notifications-response.md).

## Example Usage

```ts
const useridto = 'useridto2';

const limit = 172;

const offset = 0;

try {
  const response = await notificationsApi.getPopupNotifications(
    useridto,
    limit,
    offset
  );

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |

