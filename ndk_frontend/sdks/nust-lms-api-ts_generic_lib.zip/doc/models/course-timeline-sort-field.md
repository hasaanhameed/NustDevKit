
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `Fullname` |
| `Shortname` |
| `Id` |
| `Idnumber` |
| `Timeaccess` |

## Example

```ts
import { CourseTimelineSortField } from 'nust-lms-apilib';

const courseTimelineSortField = CourseTimelineSortField.Fullname;
```

