
# Get Calendar Events by Timesort Request

Request parameters for retrieving calendar action events sorted by time.

*This model accepts additional fields of type unknown.*

## Structure

`GetCalendarEventsByTimesortRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limitnum` | `number` | Required | Maximum number of events to return. |
| `timesortfrom` | `number` | Required | Only return events with timesort >= this Unix timestamp. Pass 0 for no lower bound. |
| `timesortto` | `number \| undefined` | Optional | Only return events with timesort <= this Unix timestamp. Optional. |
| `aftereventid` | `number \| undefined` | Optional | Return events whose ID is greater than this value (cursor pagination). Optional. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { GetCalendarEventsByTimesortRequest } from 'nust-lms-apilib';

const getCalendarEventsByTimesortRequest: GetCalendarEventsByTimesortRequest = {
  limitnum: 20,
  timesortfrom: 0,
  timesortto: 114,
  aftereventid: 112,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

