
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `FULLNAME` |
| `SHORTNAME` |
| `ID` |
| `IDNUMBER` |
| `TIMEACCESS` |

## Example

```ruby
course_timeline_sort_field = CourseTimelineSortField::FULLNAME
```

