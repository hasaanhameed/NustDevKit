
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `ID` |
| `IDNUMBER` |
| `USERNAME` |
| `EMAIL` |

## Example

```ruby
user_profile_field = UserProfileField::USERNAME
```

