
# Login Request

NUST LMS credentials used to obtain a gateway bearer token.

*This model accepts additional fields of type Object.*

## Structure

`LoginRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `username` | `String` | Required | NUST LMS username. |
| `password` | `String` | Required | NUST LMS password. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
login_request = LoginRequest.new(
  username: 'johndoe.bscs23seecs',
  password: 'password6',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

