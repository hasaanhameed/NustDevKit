
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `ALL` |
| `INPROGRESS` |
| `PAST` |
| `FUTURE` |
| `FAVOURITES` |
| `HIDDEN` |
| `ALLINCLUDINGHIDDEN` |

## Example

```ruby
course_timeline_classification = CourseTimelineClassification::FAVOURITES
```

