
# Get Enrolled Courses by Timeline Request

Request parameters for retrieving enrolled courses filtered by timeline classification.

*This model accepts additional fields of type Object.*

## Structure

`GetEnrolledCoursesByTimelineRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `offset` | `Integer` | Required | Zero-based pagination offset.<br><br>**Default**: `0` |
| `limit` | `Integer` | Required | Maximum number of courses to return.<br><br>**Default**: `50` |
| `classification` | [`CourseTimelineClassification`](../../doc/models/course-timeline-classification.md) | Required | Timeline classification filter for enrolled courses. |
| `sort` | [`CourseTimelineSortField`](../../doc/models/course-timeline-sort-field.md) | Required | Field used to sort enrolled course results. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_enrolled_courses_by_timeline_request = GetEnrolledCoursesByTimelineRequest.new(
  offset: 0,
  limit: 50,
  classification: CourseTimelineClassification::ALLINCLUDINGHIDDEN,
  sort: CourseTimelineSortField::IDNUMBER,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

