
# Event Subscription

Subscription display settings for a calendar event.

*This model accepts additional fields of type Object.*

## Structure

`EventSubscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `displayeventsource` | `TrueClass \| FalseClass` | Required | Whether to display the event source label on the calendar. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
event_subscription = EventSubscription.new(
  displayeventsource: false,
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

