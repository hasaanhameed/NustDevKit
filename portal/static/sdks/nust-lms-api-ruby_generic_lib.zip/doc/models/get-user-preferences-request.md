
# Get User Preferences Request

Request parameters for retrieving user preferences.

*This model accepts additional fields of type Object.*

## Structure

`GetUserPreferencesRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userid` | `Integer` | Required | ID of the user whose preferences to retrieve. |
| `name` | `String` | Optional | Specific preference name to retrieve. Omit to retrieve all preferences. |
| `additional_properties` | `Hash[String, Object]` | Optional | - |

## Example

```ruby
get_user_preferences_request = GetUserPreferencesRequest.new(
  userid: 162154,
  name: 'name2',
  additional_properties: {
    'exampleAdditionalProperty' => JSON.parse('{"key1":"val1","key2":"val2"}')
  }
)
```

