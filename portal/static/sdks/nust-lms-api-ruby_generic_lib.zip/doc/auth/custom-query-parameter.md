
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| sesskey | `String` | Session key obtained after authenticating with the LMS portal. | `sesskey` |



**Note:** Auth credentials can be set using named parameter for any of the above credentials (e.g. `sesskey`) in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ruby
require 'nust_lms_api'
include NustLmsApi

client = Client.new(
  custom_query_authentication_credentials: CustomQueryAuthenticationCredentials.new(
    sesskey: 'sesskey'
  )
)
```


