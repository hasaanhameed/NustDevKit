# Authentication

Exchange NUST LMS credentials for a gateway bearer token

```ruby
authentication_api = client.authentication
```

## Class Name

`AuthenticationApi`


# Login

Authenticates against NUST LMS on your behalf and returns a gateway JWT. The LMS session (cookie + sesskey) is created and held server-side; use the returned token as `Authorization: Bearer <token>` for every other operation.

:information_source: **Note** This endpoint does not require authentication.

```ruby
def login(body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LoginRequest`](../../doc/models/login-request.md) | Body, Required | NUST LMS credentials. |

## Response Type

**200**: Authentication succeeded; bearer token issued.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `data` property of this instance returns the response data which is of type [`TokenResponse`](../../doc/models/token-response.md).

## Example Usage

```ruby
body = LoginRequest.new(
  username: 'johndoe.bscs23seecs',
  password: 'password0'
)

result = authentication_api.login(body)

if result.success?
  puts result.data
elsif result.error?
  warn result.errors
end
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid LMS credentials. | [`AuthLogin401ErrorException`](../../doc/models/auth-login-401-error-exception.md) |

