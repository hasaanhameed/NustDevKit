Gem::Specification.new do |s|
  s.name = 'nust_lms_api'
  s.version = '1.0.0'
  s.summary = 'nust_lms_api'
  s.description = 'NUST Learning Management System API for developer integrations (Moodle AJAX wrapper). Authenticate with your NUST LMS credentials via `POST /auth/login` to receive a bearer token, then call any operation with `Authorization: Bearer <token>`. The NustDevKit gateway logs into the LMS on your behalf and manages the underlying session (cookie + sesskey) server-side, so you never handle the ephemeral sesskey.'
  s.authors = ['NustDevKit Support']
  s.email = ['support@apimatic.io']
  s.homepage = 'https://github.com/hasaanhameed52/NustDevKit'
  s.licenses = ['MIT']
  s.add_dependency('apimatic_core_interfaces', '~> 0.2.3')
  s.add_dependency('apimatic_core', '~> 0.3.20')
  s.add_dependency('apimatic_faraday_client_adapter', '~> 0.1.6')
  s.required_ruby_version = ['>= 2.6']
  s.files = Dir['{bin,lib,man,test,spec}/**/*', 'README*', 'LICENSE*']
  s.require_paths = ['lib']
end
