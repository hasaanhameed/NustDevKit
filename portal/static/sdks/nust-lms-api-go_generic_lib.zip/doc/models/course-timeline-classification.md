
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `All` |
| `Inprogress` |
| `Past` |
| `Future` |
| `Favourite` |
| `Hidden` |
| `Allincludinghidden` |

## Example

```go
package main

import (
    "nustLmsApi/models"
)

func main() {
    courseTimelineClassification := models.CourseTimelineClassification_Future

}
```

