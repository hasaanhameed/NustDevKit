# Users

User profile and preferences operations

```go
usersApi := client.UsersApi()
```

## Class Name

`UsersApi`

## Methods

* [Get Users by Field](../../doc/controllers/users.md#get-users-by-field)
* [Get User Preferences](../../doc/controllers/users.md#get-user-preferences)


# Get Users by Field

Retrieves one or more user profiles by matching a specific profile field. Commonly used to look up the authenticated user's own profile by their ID.
Moodle method: `core_user_get_users_by_field`

```go
GetUsersByField(
    ctx context.Context,
    body models.GetUsersByFieldRequest) (
    models.ApiResponse[[]models.UserProfile],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GetUsersByFieldRequest`](../../doc/models/get-users-by-field-request.md) | Body, Required | Parameters specifying the profile field and values to match. |

## Response Type

**200**: List of matching user profiles.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.UserProfile](../../doc/models/user-profile.md).

## Example Usage

```go
ctx := context.Background()

body := models.GetUsersByFieldRequest{
    Field:                 models.UserProfileField_Id,
    Values:                []string{
        "123456",
    },
}

apiResponse, err := usersApi.GetUsersByField(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get User Preferences

Returns all stored preference key/value pairs for the specified user. Optionally filter to a single preference by name.
Moodle method: `core_user_get_user_preferences`

```go
GetUserPreferences(
    ctx context.Context,
    body models.GetUserPreferencesRequest) (
    models.ApiResponse[models.UserPreferencesResponse],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`models.GetUserPreferencesRequest`](../../doc/models/get-user-preferences-request.md) | Body, Required | Parameters specifying which user's preferences to retrieve. |

## Response Type

**200**: User preferences list and optional warnings.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.UserPreferencesResponse](../../doc/models/user-preferences-response.md).

## Example Usage

```go
ctx := context.Background()

body := models.GetUserPreferencesRequest{
    Userid:                123456,
}

apiResponse, err := usersApi.GetUserPreferences(ctx, body)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

