
# Popup Notifications Response

Response envelope for the popup-notifications endpoint.

*This model accepts additional fields of type object.*

## Structure

`PopupNotificationsResponse`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Notifications` | [`List<Notification>`](../../doc/models/notification.md) | Required | List of popup notifications for the user. |
| `Unreadcount` | `int` | Required | Total number of unread notifications for the user. |
| `AdditionalProperties` | `object this[string key]` | Optional | - |

## Example

```csharp
using NustLmsApi.Standard.Models;
using NustLmsApi.Standard.Utilities;
using System.Collections.Generic;

PopupNotificationsResponse popupNotificationsResponse = new PopupNotificationsResponse
{
    Notifications = new List<Notification>
    {
        new Notification
        {
            Id = 4857819,
            Useridfrom = 198956,
            Useridto = 162154,
            Subject = "CS-419-Deep Learning: Lab Sessional Finalization",
            Shortenedsubject = "CS-419-Deep Learning: Lab Sessional Finalization",
            Text = "<p>Areeba Rameen posted in CS-419-Deep Learning...</p>",
            Fullmessage = "fullmessage8",
            Fullmessageformat = 2,
            Fullmessagehtml = "fullmessagehtml4",
            Smallmessage = "Areeba Rameen posted in CS-419-Deep Learning...",
            Contexturl = "https://lms.nust.edu.pk/portal/mod/forum/discuss.php?d=41767#p52342",
            Contexturlname = "Lab Sessional Finalization - (DL - Section D & E)",
            Timecreated = 1780045085,
            Timecreatedpretty = "19 days ago",
            Read = false,
            Deleted = false,
            Iconurl = "https://lms.nust.edu.pk/portal/theme/image.php/moove/mod_forum/1778048051/icon",
            Component = "mod_forum",
            Eventtype = "posts",
            Customdata = "{\"cmid\":\"1272420\",\"instance\":\"62569\",\"discussionid\":\"41767\"}",
            Timeread = 152,
            ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
        },
    },
    Unreadcount = 1,
    ["exampleAdditionalProperty"] = ApiHelper.JsonDeserialize<object>("{\"key1\":\"val1\",\"key2\":\"val2\"}"),
};
```

