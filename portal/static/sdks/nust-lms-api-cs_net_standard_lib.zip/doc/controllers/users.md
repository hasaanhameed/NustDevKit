# Users

User profile and preferences operations

```csharp
UsersApi usersApi = client.UsersApi;
```

## Class Name

`UsersApi`

## Methods

* [Get Users by Field](../../doc/controllers/users.md#get-users-by-field)
* [Get User Preferences](../../doc/controllers/users.md#get-user-preferences)


# Get Users by Field

Retrieves one or more user profiles by matching a specific profile field. Commonly used to look up the authenticated user's own profile by their ID.
Moodle method: `core_user_get_users_by_field`

```csharp
GetUsersByFieldAsync(
    Models.GetUsersByFieldRequest body)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetUsersByFieldRequest`](../../doc/models/get-users-by-field-request.md) | Body, Required | Parameters specifying the profile field and values to match. |

## Response Type

**200**: List of matching user profiles.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [List<Models.UserProfile>](../../doc/models/user-profile.md).

## Example Usage

```csharp
GetUsersByFieldRequest body = new GetUsersByFieldRequest
{
    Field = UserProfileField.Id,
    Values = new List<string>
    {
        "162154",
    },
};

try
{
    ApiResponse<List<UserProfile>> result = await usersApi.GetUsersByFieldAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get User Preferences

Returns all stored preference key/value pairs for the specified user. Optionally filter to a single preference by name.
Moodle method: `core_user_get_user_preferences`

```csharp
GetUserPreferencesAsync(
    Models.GetUserPreferencesRequest body)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetUserPreferencesRequest`](../../doc/models/get-user-preferences-request.md) | Body, Required | Parameters specifying which user's preferences to retrieve. |

## Response Type

**200**: User preferences list and optional warnings.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [Models.UserPreferencesResponse](../../doc/models/user-preferences-response.md).

## Example Usage

```csharp
GetUserPreferencesRequest body = new GetUserPreferencesRequest
{
    Userid = 162154,
};

try
{
    ApiResponse<UserPreferencesResponse> result = await usersApi.GetUserPreferencesAsync(body);
}
catch (ApiException e)
{
    Console.WriteLine(e.Message);
    if (e is MoodleErrorException)
    {
       // TODO: Handle MoodleErrorException exception here
    }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

