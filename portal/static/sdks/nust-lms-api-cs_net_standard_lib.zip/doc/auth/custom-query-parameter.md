
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| Sesskey | `string` | Session key obtained after authenticating with the LMS portal. | `Sesskey` | `Sesskey` |



**Note:** Auth credentials can be set using `CustomQueryAuthenticationCredentials` in the client builder and accessed through `CustomQueryAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```csharp
using NustLmsApi.Standard;
using NustLmsApi.Standard.Authentication;

namespace ConsoleApp;

NustLmsApiClient client = new NustLmsApiClient.Builder()
    .CustomQueryAuthenticationCredentials(
        new CustomQueryAuthenticationModel.Builder(
            "sesskey"
        )
        .Build())
    .Build();
```


