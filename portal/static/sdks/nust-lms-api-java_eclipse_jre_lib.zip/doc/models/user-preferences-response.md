
# User Preferences Response

Response envelope for the user-preferences endpoint.

*This model accepts additional fields of type Object.*

## Structure

`UserPreferencesResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Preferences` | [`List<UserPreference>`](../../doc/models/user-preference.md) | Required | List of user preference key/value pairs. | List<UserPreference> getPreferences() | setPreferences(List<UserPreference> preferences) |
| `Warnings` | [`List<MoodleWarning>`](../../doc/models/moodle-warning.md) | Required | Array of warning objects. Empty when no warnings are present. | List<MoodleWarning> getWarnings() | setWarnings(List<MoodleWarning> warnings) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import java.io.IOException;
import java.util.Arrays;
import pk.edu.nust.lms.ApiHelper;
import pk.edu.nust.lms.models.MoodleWarning;
import pk.edu.nust.lms.models.UserPreference;
import pk.edu.nust.lms.models.UserPreferencesResponse;

UserPreferencesResponse userPreferencesResponse = new UserPreferencesResponse.Builder(
    Arrays.asList(
        new UserPreference.Builder(
            "block_myoverview_user_sort_preference",
            "title"
        )
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
        .build()
    ),
    Arrays.asList(
        new MoodleWarning.Builder()
            .item("item6")
            .itemid(0)
            .warningcode("warningcode4")
            .message("message4")
        .additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
            .build()
    )
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

