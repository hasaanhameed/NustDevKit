
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `ALL` |
| `INPROGRESS` |
| `PAST` |
| `FUTURE` |
| `FAVOURITE` |
| `HIDDEN` |
| `ALLINCLUDINGHIDDEN` |

## Example

```java
import m18000.m0.m0.m127.models.CourseTimelineClassification;

CourseTimelineClassification courseTimelineClassification = CourseTimelineClassification.FUTURE;
```

