
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `ALL` |
| `INPROGRESS` |
| `PAST` |
| `FUTURE` |
| `FAVOURITE` |
| `HIDDEN` |
| `ALLINCLUDINGHIDDEN` |

## Example

```java
import pk.edu.nust.lms.models.CourseTimelineClassification;

CourseTimelineClassification courseTimelineClassification = CourseTimelineClassification.FUTURE;
```

