
# Event Subscription

Subscription display settings for a calendar event.

*This model accepts additional fields of type Object.*

## Structure

`EventSubscription`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Displayeventsource` | `boolean` | Required | Whether to display the event source label on the calendar. | boolean getDisplayeventsource() | setDisplayeventsource(boolean displayeventsource) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import java.io.IOException;
import m18000.m0.m0.m127.ApiHelper;
import m18000.m0.m0.m127.models.EventSubscription;

EventSubscription eventSubscription = new EventSubscription.Builder(
    false
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

