
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `FULLNAME` |
| `SHORTNAME` |
| `ID` |
| `IDNUMBER` |
| `TIMEACCESS` |

## Example

```java
import m18000.m0.m0.m127.models.CourseTimelineSortField;

CourseTimelineSortField courseTimelineSortField = CourseTimelineSortField.FULLNAME;
```

