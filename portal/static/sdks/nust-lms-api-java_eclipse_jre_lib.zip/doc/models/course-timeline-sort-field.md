
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `FULLNAME` |
| `SHORTNAME` |
| `ID` |
| `IDNUMBER` |
| `TIMEACCESS` |

## Example

```java
import pk.edu.nust.lms.models.CourseTimelineSortField;

CourseTimelineSortField courseTimelineSortField = CourseTimelineSortField.FULLNAME;
```

