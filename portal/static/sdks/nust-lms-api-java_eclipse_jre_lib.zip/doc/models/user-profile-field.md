
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `ID` |
| `IDNUMBER` |
| `USERNAME` |
| `EMAIL` |

## Example

```java
import m18000.m0.m0.m127.models.UserProfileField;

UserProfileField userProfileField = UserProfileField.ID;
```

