
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `ID` |
| `IDNUMBER` |
| `USERNAME` |
| `EMAIL` |

## Example

```java
import pk.edu.nust.lms.models.UserProfileField;

UserProfileField userProfileField = UserProfileField.ID;
```

