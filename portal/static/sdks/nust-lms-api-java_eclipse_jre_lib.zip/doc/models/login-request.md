
# Login Request

NUST LMS credentials used to obtain a gateway bearer token.

*This model accepts additional fields of type Object.*

## Structure

`LoginRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Username` | `String` | Required | NUST LMS username. | String getUsername() | setUsername(String username) |
| `Password` | `String` | Required | NUST LMS password. | String getPassword() | setPassword(String password) |
| `AdditionalProperties` | `Map<String, Object>` | Optional | - | Object getAdditionalProperty(String key) | additionalProperty(String key, Object value) |

## Example

```java
import java.io.IOException;
import m18000.m0.m0.m127.ApiHelper;
import m18000.m0.m0.m127.models.LoginRequest;

LoginRequest loginRequest = new LoginRequest.Builder(
    "johndoe.bscs23seecs",
    "password2"
)
.additionalProperty("exampleAdditionalProperty", ApiHelper.deserialize("{\"key1\":\"val1\",\"key2\":\"val2\"}"))
.build();
```

