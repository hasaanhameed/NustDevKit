# Notifications

Notification retrieval operations

```java
NotificationsApi notificationsApi = client.getNotificationsApi();
```

## Class Name

`NotificationsApi`

## Methods

* [Fetch Notifications](../../doc/controllers/notifications.md#fetch-notifications)
* [Get Popup Notifications](../../doc/controllers/notifications.md#get-popup-notifications)


# Fetch Notifications

Returns pending site-level notifications for the given Moodle context. Returns an empty array when there are no pending notifications.
Moodle method: `core_fetch_notifications`

```java
CompletableFuture<ApiResponse<List<SiteNotification>>> fetchNotificationsAsync(
    final FetchNotificationsRequest body)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`FetchNotificationsRequest`](../../doc/models/fetch-notifications-request.md) | Body, Required | Parameters specifying the context to fetch notifications for. |

## Response Type

**200**: Array of site notifications (empty array when none are pending).

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`List<SiteNotification>`](../../doc/models/site-notification.md).

## Example Usage

```java
FetchNotificationsRequest body = new FetchNotificationsRequest.Builder(
    1583361
)
.build();

notificationsApi.fetchNotificationsAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof MoodleErrorException) {
        MoodleErrorException moodleErrorException = (MoodleErrorException) cause;
        moodleErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Popup Notifications

Returns the most recent popup notifications sent to a user, with support for pagination. Also returns the total count of unread notifications.
Moodle method: `message_popup_get_popup_notifications`

```java
CompletableFuture<ApiResponse<PopupNotificationsResponse>> getPopupNotificationsAsync(
    final GetPopupNotificationsRequest body)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetPopupNotificationsRequest`](../../doc/models/get-popup-notifications-request.md) | Body, Required | Parameters for the popup notifications request. |

## Response Type

**200**: Popup notifications and total unread count.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`PopupNotificationsResponse`](../../doc/models/popup-notifications-response.md).

## Example Usage

```java
GetPopupNotificationsRequest body = new GetPopupNotificationsRequest.Builder(
    "162154",
    20,
    0
)
.build();

notificationsApi.getPopupNotificationsAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof MoodleErrorException) {
        MoodleErrorException moodleErrorException = (MoodleErrorException) cause;
        moodleErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

