# Authentication

Exchange NUST LMS credentials for a gateway bearer token

```java
AuthenticationApi authenticationApi = client.getAuthenticationApi();
```

## Class Name

`AuthenticationApi`


# Login

Authenticates against NUST LMS on your behalf and returns a gateway JWT. The LMS session (cookie + sesskey) is created and held server-side; use the returned token as `Authorization: Bearer <token>` for every other operation.

:information_source: **Note** This endpoint does not require authentication.

```java
CompletableFuture<ApiResponse<TokenResponse>> loginAsync(
    final LoginRequest body)
```

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`LoginRequest`](../../doc/models/login-request.md) | Body, Required | NUST LMS credentials. |

## Response Type

**200**: Authentication succeeded; bearer token issued.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` getter of this instance returns the response data which is of type [`TokenResponse`](../../doc/models/token-response.md).

## Example Usage

```java
LoginRequest body = new LoginRequest.Builder(
    "johndoe.bscs23seecs",
    "password0"
)
.build();

authenticationApi.loginAsync(body).thenAccept(result -> {
    // TODO success callback handler
    System.out.println(result);
}).exceptionally(exception -> {
    Throwable cause = exception.getCause();

    if (cause instanceof AuthLogin401ErrorException) {
        AuthLogin401ErrorException authLogin401ErrorException = (AuthLogin401ErrorException) cause;
        authLogin401ErrorException.printStackTrace();
    } else {
        // fallback for unexpected errors
        exception.printStackTrace();
    }

    return null;
});
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 401 | Invalid LMS credentials. | [`AuthLogin401ErrorException`](../../doc/models/auth-login-401-error-exception.md) |

