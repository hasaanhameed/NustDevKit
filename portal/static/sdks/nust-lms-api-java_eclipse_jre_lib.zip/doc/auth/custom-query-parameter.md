
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| sesskey | `String` | Session key obtained after authenticating with the LMS portal. | `sesskey` | `getSesskey()` |



**Note:** Auth credentials can be set using `customQueryAuthenticationCredentials` in the client builder and accessed through `getCustomQueryAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```java
import pk.edu.nust.lms.NustLmsApiClient;
import pk.edu.nust.lms.authentication.CustomQueryAuthenticationModel;

public class Program {
    public static void main(String[] args) {
        NustLmsApiClient client = new NustLmsApiClient.Builder()
            .customQueryAuthenticationCredentials(new CustomQueryAuthenticationModel.Builder(
                    "sesskey"
                )
                .build())
            .build();
    }
}
```


