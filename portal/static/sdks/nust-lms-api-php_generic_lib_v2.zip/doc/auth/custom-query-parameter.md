
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Setter | Getter |
|  --- | --- | --- | --- | --- |
| sesskey | `string` | Session key obtained after authenticating with the LMS portal. | `sesskey` | `getSesskey()` |



**Note:** Auth credentials can be set using `CustomQueryAuthenticationCredentialsBuilder::init()` in `customQueryAuthenticationCredentials` method in the client builder and accessed through `getCustomQueryAuthenticationCredentials` method in the client instance.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```php
use NustLmsApiLib\Authentication\CustomQueryAuthenticationCredentialsBuilder;
use NustLmsApiLib\NustLmsApiClientBuilder;

$client = NustLmsApiClientBuilder::init()
    ->customQueryAuthenticationCredentials(
        CustomQueryAuthenticationCredentialsBuilder::init(
            'sesskey'
        )
    )
    ->build();
```


