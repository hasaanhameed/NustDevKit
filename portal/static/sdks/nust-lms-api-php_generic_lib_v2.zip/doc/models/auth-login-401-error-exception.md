
# Auth Login 401 Error Exception

*This model accepts additional fields of type array.*

## Structure

`AuthLogin401ErrorException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `detail` | `?string` | Optional | - | getDetail(): ?string | setDetail(?string detail): void |
| `additionalProperties` | `array<string, array>` | Optional | - | findAdditionalProperty(string key): array | additionalProperty(string key, array value): void |

