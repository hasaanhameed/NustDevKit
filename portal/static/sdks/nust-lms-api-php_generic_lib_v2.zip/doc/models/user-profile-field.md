
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `ID` |
| `IDNUMBER` |
| `USERNAME` |
| `EMAIL` |

## Example

```php
use NustLmsApiLib\Models\UserProfileField;

$userProfileField = UserProfileField::ID;
```

