
# Course Timeline Sort Field

Field used to sort enrolled course results.

## Enumeration

`CourseTimelineSortField`

## Fields

| Name |
|  --- |
| `FULLNAME` |
| `SHORTNAME` |
| `ID` |
| `IDNUMBER` |
| `TIMEACCESS` |

## Example

```php
use NustLmsApiLib\Models\CourseTimelineSortField;

$courseTimelineSortField = CourseTimelineSortField::FULLNAME;
```

