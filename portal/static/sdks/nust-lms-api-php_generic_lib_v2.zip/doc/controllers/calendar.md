# Calendar

Calendar operations. On NUST LMS, these "action events" are how deadlines are surfaced — assignment, lab, quiz, and other submission due dates each appear as a calendar event on the day the work must be submitted.

```php
$calendarApi = $client->getCalendarApi();
```

## Class Name

`CalendarApi`

## Methods

* [Get Calendar Events by Timesort](../../doc/controllers/calendar.md#get-calendar-events-by-timesort)
* [Get Calendar Events by Course](../../doc/controllers/calendar.md#get-calendar-events-by-course)


# Get Calendar Events by Timesort

Returns action events (deadlines) across all enrolled courses, ordered by their sort timestamp. On NUST LMS these are submission due dates for assignments, labs, quizzes, and similar dated activities. Use `timesortfrom` to filter to upcoming deadlines only.
Moodle method: `core_calendar_get_action_events_by_timesort`

```php
function getCalendarEventsByTimesort(GetCalendarEventsByTimesortRequest $body): ApiResponse
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetCalendarEventsByTimesortRequest`](../../doc/models/get-calendar-events-by-timesort-request.md) | Body, Required | Parameters for the time-sorted calendar events request. |

## Response Type

**200**: Calendar events sorted by timesort.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```php
$body = GetCalendarEventsByTimesortRequestBuilder::init(
    20,
    0
)->build();

$calendarApi = $client->getCalendarApi();
$apiResponse = $calendarApi->getCalendarEventsByTimesort($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CalendarEventsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Calendar Events by Course

Returns all action events (deadlines) for a single course — assignment, lab, and quiz submission due dates, and other dated activities.
Moodle method: `core_calendar_get_action_events_by_course`

```php
function getCalendarEventsByCourse(GetCalendarEventsByCourseRequest $body): ApiResponse
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetCalendarEventsByCourseRequest`](../../doc/models/get-calendar-events-by-course-request.md) | Body, Required | Parameters for the course-specific calendar events request. |

## Response Type

**200**: Calendar events for the specified course.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```php
$body = GetCalendarEventsByCourseRequestBuilder::init(
    49906
)->build();

$calendarApi = $client->getCalendarApi();
$apiResponse = $calendarApi->getCalendarEventsByCourse($body);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'CalendarEventsResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

