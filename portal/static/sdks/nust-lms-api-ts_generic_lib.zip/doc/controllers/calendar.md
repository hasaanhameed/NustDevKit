# Calendar

Calendar event operations

```ts
const calendarApi = new CalendarApi(client);
```

## Class Name

`CalendarApi`

## Methods

* [Get Calendar Events by Timesort](../../doc/controllers/calendar.md#get-calendar-events-by-timesort)
* [Get Calendar Events by Course](../../doc/controllers/calendar.md#get-calendar-events-by-course)


# Get Calendar Events by Timesort

Returns action events across all enrolled courses, ordered by their sort timestamp. Use `timesortfrom` to filter to upcoming events only.
Moodle method: `core_calendar_get_action_events_by_timesort`

```ts
async getCalendarEventsByTimesort(
  body: GetCalendarEventsByTimesortRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<CalendarEventsResponse>>
```

## Authentication

This endpoint requires [SessKey](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetCalendarEventsByTimesortRequest`](../../doc/models/get-calendar-events-by-timesort-request.md) | Body, Required | Parameters for the time-sorted calendar events request. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Calendar events sorted by timesort.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```ts
const body: GetCalendarEventsByTimesortRequest = {
  limitnum: 20,
  timesortfrom: 0,
};

try {
  const response = await calendarApi.getCalendarEventsByTimesort(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |


# Get Calendar Events by Course

Returns all action events (assignments, quizzes, etc.) for a single course.
Moodle method: `core_calendar_get_action_events_by_course`

```ts
async getCalendarEventsByCourse(
  body: GetCalendarEventsByCourseRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<CalendarEventsResponse>>
```

## Authentication

This endpoint requires [SessKey](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetCalendarEventsByCourseRequest`](../../doc/models/get-calendar-events-by-course-request.md) | Body, Required | Parameters for the course-specific calendar events request. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: Calendar events for the specified course.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```ts
const body: GetCalendarEventsByCourseRequest = {
  courseid: 49906,
};

try {
  const response = await calendarApi.getCalendarEventsByCourse(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |

