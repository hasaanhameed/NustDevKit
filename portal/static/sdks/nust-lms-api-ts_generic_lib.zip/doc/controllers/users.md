# Users

User profile and preferences operations

```ts
const usersApi = new UsersApi(client);
```

## Class Name

`UsersApi`

## Methods

* [Get Users by Field](../../doc/controllers/users.md#get-users-by-field)
* [Get User Preferences](../../doc/controllers/users.md#get-user-preferences)


# Get Users by Field

Retrieves one or more user profiles by matching a specific profile field. Commonly used to look up the authenticated user's own profile by their ID.
Moodle method: `core_user_get_users_by_field`

```ts
async getUsersByField(
  body: GetUsersByFieldRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserProfile[]>>
```

## Authentication

This endpoint requires [SessKey](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetUsersByFieldRequest`](../../doc/models/get-users-by-field-request.md) | Body, Required | Parameters specifying the profile field and values to match. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: List of matching user profiles.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`UserProfile[]`](../../doc/models/user-profile.md).

## Example Usage

```ts
const body: GetUsersByFieldRequest = {
  field: UserProfileField.Id,
  values: [
    '162154'
  ],
};

try {
  const response = await usersApi.getUsersByField(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |


# Get User Preferences

Returns all stored preference key/value pairs for the specified user. Optionally filter to a single preference by name.
Moodle method: `core_user_get_user_preferences`

```ts
async getUserPreferences(
  body: GetUserPreferencesRequest,
  requestOptions?: RequestOptions
): Promise<ApiResponse<UserPreferencesResponse>>
```

## Authentication

This endpoint requires [SessKey](../../doc/auth/custom-query-parameter.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `body` | [`GetUserPreferencesRequest`](../../doc/models/get-user-preferences-request.md) | Body, Required | Parameters specifying which user's preferences to retrieve. |
| `requestOptions` | `RequestOptions \| undefined` | Optional | Pass additional request options. |

## Response Type

**200**: User preferences list and optional warnings.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `result` property of this instance returns the response data which is of type [`UserPreferencesResponse`](../../doc/models/user-preferences-response.md).

## Example Usage

```ts
const body: GetUserPreferencesRequest = {
  userid: 162154,
};

try {
  const response = await usersApi.getUserPreferences(body);

  // Extracting fully parsed response body.
  console.log(response.result);

  // Extracting response status code.
  console.log(response.statusCode);
  // Extracting response headers.
  console.log(response.headers);
  // Extracting response body of type `string | Stream`
  console.log(response.body);
} catch (error) {
  if (error instanceof ApiError) {
    // Extracting response error status code.
    console.log(error.statusCode);
    // Extracting response error headers.
    console.log(error.headers);
    // Extracting response error body of type `string | Stream`.
    console.log(error.body);
    if (error instanceof MoodleError) {
      console.log(error.result);
    }
  }
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleError`](../../doc/models/moodle-error.md) |

