
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Setter |
|  --- | --- | --- | --- |
| sesskey | `string` | Session key obtained after authenticating with the LMS portal. | `sesskey` |



**Note:** Auth credentials can be set using `customQueryAuthenticationCredentials` object in the client.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```ts
import { Client } from 'nust-lms-apilib';

const client = new Client({
  customQueryAuthenticationCredentials: {
    'sesskey': 'sesskey'
  },
});
```


