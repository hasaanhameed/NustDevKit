
# Fetch Notifications Request

Request parameters for fetching site-level notifications.

*This model accepts additional fields of type unknown.*

## Structure

`FetchNotificationsRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `contextid` | `number` | Required | Moodle context ID for which to fetch notifications. The user context ID can be found in the user profile image URL path segment. |
| `additionalProperties` | `Record<string, unknown>` | Optional | - |

## Example

```ts
import { FetchNotificationsRequest } from 'nust-lms-apilib';

const fetchNotificationsRequest: FetchNotificationsRequest = {
  contextid: 1583361,
  additionalProperties: {
    'exampleAdditionalProperty': { 'key1': 'val1', 'key2': 'val2' }
  },
};
```

