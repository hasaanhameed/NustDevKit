
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `All` |
| `Inprogress` |
| `Past` |
| `Future` |
| `Favourite` |
| `Hidden` |
| `Allincludinghidden` |

## Example

```ts
import { CourseTimelineClassification } from 'nust-lms-apilib';

const courseTimelineClassification = CourseTimelineClassification.Future;
```

