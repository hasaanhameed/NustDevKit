
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `Id` |
| `Idnumber` |
| `Username` |
| `Email` |

## Example

```ts
import { UserProfileField } from 'nust-lms-apilib';

const userProfileField = UserProfileField.Id;
```

