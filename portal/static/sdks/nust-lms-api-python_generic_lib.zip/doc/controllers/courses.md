# Courses

Course listing and enrollment operations

```python
courses_api = client.courses
```

## Class Name

`CoursesApi`

## Methods

* [Get Core Recent Courses](../../doc/controllers/courses.md#get-core-recent-courses)
* [Get Enrolled Courses by Timeline](../../doc/controllers/courses.md#get-enrolled-courses-by-timeline)
* [Get Course Contents](../../doc/controllers/courses.md#get-course-contents)


# Get Core Recent Courses

Returns the courses the authenticated user has accessed most recently, ordered by last access time.
Moodle method: `core_course_get_recent_courses`

```python
def get_core_recent_courses(self,
                           limit)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |

## Response Type

**200**: List of recently accessed courses ordered by last access.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[RecentCourse]`](../../doc/models/recent-course.md).

## Example Usage

```python
limit = 10

result = courses_api.get_core_recent_courses(limit)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Enrolled Courses by Timeline

Returns all courses the user is enrolled in, filtered by timeline classification and sorted by a chosen field. Supports pagination via offset.
Moodle method: `core_course_get_enrolled_courses_by_timeline_classification`

```python
def get_enrolled_courses_by_timeline(self,
                                    offset,
                                    limit,
                                    classification,
                                    sort)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `offset` | `int` | Query, Required | Zero-based pagination offset. |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |
| `classification` | [`CourseTimelineClassification`](../../doc/models/course-timeline-classification.md) | Query, Required | Timeline classification filter for enrolled courses. |
| `sort` | [`CourseTimelineSortField`](../../doc/models/course-timeline-sort-field.md) | Query, Required | Field used to sort enrolled course results. |

## Response Type

**200**: Paginated list of enrolled courses.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`EnrolledCoursesResponse`](../../doc/models/enrolled-courses-response.md).

## Example Usage

```python
offset = 0

limit = 50

classification = CourseTimelineClassification.INPROGRESS

sort = CourseTimelineSortField.IDNUMBER

result = courses_api.get_enrolled_courses_by_timeline(
    offset,
    limit,
    classification,
    sort
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Course Contents

Returns the full content structure of a course — its sections (weeks/topics) and the modules within them (files, folders, pages, URLs, assignments, and other activities), including metadata for each uploaded file. This is the data the course page itself is built from.
Note: file URLs point at Moodle's `pluginfile.php` and require authentication (a webservice token or the active session) to download — the URL alone is not publicly fetchable.
Moodle method: `core_course_get_contents`

```python
def get_course_contents(self,
                       courseid)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `courseid` | `int` | Query, Required | ID of the course whose contents to retrieve. |

## Response Type

**200**: Course sections, each with its modules and their uploaded files.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`List[CourseSection]`](../../doc/models/course-section.md).

## Example Usage

```python
courseid = 74

result = courses_api.get_course_contents(courseid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

