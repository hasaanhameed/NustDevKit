# Calendar

Calendar operations. On NUST LMS, these "action events" are how deadlines are surfaced — assignment, lab, quiz, and other submission due dates each appear as a calendar event on the day the work must be submitted.

```python
calendar_api = client.calendar
```

## Class Name

`CalendarApi`

## Methods

* [Get Calendar Events by Timesort](../../doc/controllers/calendar.md#get-calendar-events-by-timesort)
* [Get Calendar Events by Course](../../doc/controllers/calendar.md#get-calendar-events-by-course)


# Get Calendar Events by Timesort

Returns action events (deadlines) across all enrolled courses, ordered by their sort timestamp. On NUST LMS these are submission due dates for assignments, labs, quizzes, and similar dated activities. Use `timesortfrom` to filter to upcoming deadlines only.
Moodle method: `core_calendar_get_action_events_by_timesort`

```python
def get_calendar_events_by_timesort(self,
                                   limitnum,
                                   timesortfrom,
                                   timesortto=None,
                                   aftereventid=None)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limitnum` | `int` | Query, Required | Maximum number of events to return (e.g. 20 for one page of results). |
| `timesortfrom` | `int` | Query, Required | Unix timestamp (seconds since epoch). Only events with a sort time at or after this value are returned. Pass `0` for no lower bound (all upcoming and past events). To see only upcoming deadlines, pass the current epoch time (e.g. the output of `Date.now() / 1000 \| 0` in JS or `int(time.time())` in Python). |
| `timesortto` | `int` | Query, Optional | Only return events with timesort <= this Unix timestamp. |
| `aftereventid` | `int` | Query, Optional | Return events whose ID is greater than this value (cursor pagination). |

## Response Type

**200**: Calendar events sorted by timesort.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```python
limitnum = 20

timesortfrom = 0

result = calendar_api.get_calendar_events_by_timesort(
    limitnum,
    timesortfrom
)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Calendar Events by Course

Returns all action events (deadlines) for a single course — assignment, lab, and quiz submission due dates, and other dated activities.
Moodle method: `core_calendar_get_action_events_by_course`

```python
def get_calendar_events_by_course(self,
                                 courseid,
                                 timesortfrom=None,
                                 timesortto=None,
                                 aftereventid=None,
                                 limitnum=None)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `courseid` | `int` | Query, Required | ID of the course to fetch events for. |
| `timesortfrom` | `int` | Query, Optional | Only return events with timesort >= this Unix timestamp. |
| `timesortto` | `int` | Query, Optional | Only return events with timesort <= this Unix timestamp. |
| `aftereventid` | `int` | Query, Optional | Cursor-based pagination — return events after this event ID. |
| `limitnum` | `int` | Query, Optional | Maximum number of events to return. |

## Response Type

**200**: Calendar events for the specified course.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `body` property of this instance returns the response data which is of type [`CalendarEventsResponse`](../../doc/models/calendar-events-response.md).

## Example Usage

```python
courseid = 74

result = calendar_api.get_calendar_events_by_course(courseid)

if result.is_success():
    print(result.body)
elif result.is_error():
    print(result.errors)
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

