
# Custom Query Parameter



Documentation for accessing and setting credentials for SessKey.

## Auth Credentials

| Name | Type | Description | Getter |
|  --- | --- | --- | --- |
| sesskey | `str` | Session key obtained after authenticating with the LMS portal. | `sesskey` |



**Note:** Auth credentials can be set using `CustomQueryAuthenticationCredentials` object, passed in as named parameter `custom_query_authentication_credentials` in the client initialization.

## Usage Example

### Client Initialization

You must provide credentials in the client as shown in the following code snippet.

```python
from nustlmsapi.http.auth.custom_query_authentication import CustomQueryAuthenticationCredentials
from nustlmsapi.nustlmsapi_client import NustlmsapiClient

client = NustlmsapiClient(
    custom_query_authentication_credentials=CustomQueryAuthenticationCredentials(
        sesskey='sesskey'
    )
)
```


