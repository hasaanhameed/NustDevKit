# Courses

Course listing and enrollment operations

```php
$coursesApi = $client->getCoursesApi();
```

## Class Name

`CoursesApi`

## Methods

* [Get Core Recent Courses](../../doc/controllers/courses.md#get-core-recent-courses)
* [Get Enrolled Courses by Timeline](../../doc/controllers/courses.md#get-enrolled-courses-by-timeline)


# Get Core Recent Courses

Returns the courses the authenticated user has accessed most recently, ordered by last access time.
Moodle method: `core_course_get_recent_courses`

```php
function getCoreRecentCourses(int $limit): ApiResponse
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |

## Response Type

**200**: List of recently accessed courses ordered by last access.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`RecentCourse[]`](../../doc/models/recent-course.md).

## Example Usage

```php
$limit = 10;

$coursesApi = $client->getCoursesApi();
$apiResponse = $coursesApi->getCoreRecentCourses($limit);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'RecentCourse[]:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Enrolled Courses by Timeline

Returns all courses the user is enrolled in, filtered by timeline classification and sorted by a chosen field. Supports pagination via offset.
Moodle method: `core_course_get_enrolled_courses_by_timeline_classification`

```php
function getEnrolledCoursesByTimeline(
    int $offset,
    int $limit,
    string $classification,
    string $sort
): ApiResponse
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `offset` | `int` | Query, Required | Zero-based pagination offset. |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |
| `classification` | [`string(CourseTimelineClassification)`](../../doc/models/course-timeline-classification.md) | Query, Required | Timeline classification filter for enrolled courses. |
| `sort` | [`string(CourseTimelineSortField)`](../../doc/models/course-timeline-sort-field.md) | Query, Required | Field used to sort enrolled course results. |

## Response Type

**200**: Paginated list of enrolled courses.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `getResult()` method on this instance returns the response data which is of type [`EnrolledCoursesResponse`](../../doc/models/enrolled-courses-response.md).

## Example Usage

```php
$offset = 0;

$limit = 50;

$classification = CourseTimelineClassification::INPROGRESS;

$sort = CourseTimelineSortField::IDNUMBER;

$coursesApi = $client->getCoursesApi();
$apiResponse = $coursesApi->getEnrolledCoursesByTimeline(
    $offset,
    $limit,
    $classification,
    $sort
);

// Extracting response status code
var_dump($apiResponse->getStatusCode());
// Extracting response headers
var_dump($apiResponse->getHeaders());

if ($apiResponse->isSuccess()) {
    echo 'EnrolledCoursesResponse:';
    var_dump($apiResponse->getResult());
} else {
    $error = $apiResponse->getResult();
    var_dump($error);
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

