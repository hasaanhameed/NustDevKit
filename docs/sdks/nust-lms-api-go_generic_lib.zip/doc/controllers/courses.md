# Courses

Course listing and enrollment operations

```go
coursesApi := client.CoursesApi()
```

## Class Name

`CoursesApi`

## Methods

* [Get Core Recent Courses](../../doc/controllers/courses.md#get-core-recent-courses)
* [Get Enrolled Courses by Timeline](../../doc/controllers/courses.md#get-enrolled-courses-by-timeline)


# Get Core Recent Courses

Returns the courses the authenticated user has accessed most recently, ordered by last access time.
Moodle method: `core_course_get_recent_courses`

```go
GetCoreRecentCourses(
    ctx context.Context,
    limit int) (
    models.ApiResponse[[]models.RecentCourse],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |

## Response Type

**200**: List of recently accessed courses ordered by last access.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.RecentCourse](../../doc/models/recent-course.md).

## Example Usage

```go
ctx := context.Background()

limit := 10

apiResponse, err := coursesApi.GetCoreRecentCourses(ctx, limit)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get Enrolled Courses by Timeline

Returns all courses the user is enrolled in, filtered by timeline classification and sorted by a chosen field. Supports pagination via offset.
Moodle method: `core_course_get_enrolled_courses_by_timeline_classification`

```go
GetEnrolledCoursesByTimeline(
    ctx context.Context,
    offset int,
    limit int,
    classification models.CourseTimelineClassification,
    sort models.CourseTimelineSortField) (
    models.ApiResponse[models.EnrolledCoursesResponse],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `offset` | `int` | Query, Required | Zero-based pagination offset. |
| `limit` | `int` | Query, Required | Maximum number of courses to return. |
| `classification` | [`models.CourseTimelineClassification`](../../doc/models/course-timeline-classification.md) | Query, Required | Timeline classification filter for enrolled courses. |
| `sort` | [`models.CourseTimelineSortField`](../../doc/models/course-timeline-sort-field.md) | Query, Required | Field used to sort enrolled course results. |

## Response Type

**200**: Paginated list of enrolled courses.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.EnrolledCoursesResponse](../../doc/models/enrolled-courses-response.md).

## Example Usage

```go
ctx := context.Background()

offset := 0

limit := 50

classification := models.CourseTimelineClassification_Inprogress

sort := models.CourseTimelineSortField_Idnumber

apiResponse, err := coursesApi.GetEnrolledCoursesByTimeline(ctx, offset, limit, classification, sort)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

