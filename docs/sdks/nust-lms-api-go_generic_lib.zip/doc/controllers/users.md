# Users

User profile and preferences operations

```go
usersApi := client.UsersApi()
```

## Class Name

`UsersApi`

## Methods

* [Get Users by Field](../../doc/controllers/users.md#get-users-by-field)
* [Get User Preferences](../../doc/controllers/users.md#get-user-preferences)


# Get Users by Field

Retrieves one or more user profiles by matching a specific profile field. Commonly used to look up the authenticated user's own profile by their ID.
Moodle method: `core_user_get_users_by_field`

```go
GetUsersByField(
    ctx context.Context,
    field models.UserProfileField,
    values []string) (
    models.ApiResponse[[]models.UserProfile],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `field` | [`models.UserProfileField`](../../doc/models/user-profile-field.md) | Query, Required | User profile field to match against when searching for users. |
| `values` | `[]string` | Query, Required | List of field values to look up. All values must be provided as strings even when the field is numeric (e.g., "123456" for an integer ID). |

## Response Type

**200**: List of matching user profiles.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [[]models.UserProfile](../../doc/models/user-profile.md).

## Example Usage

```go
ctx := context.Background()

field := models.UserProfileField_Id

values := []string{
    "values0",
    "values1",
    "values2",
}

apiResponse, err := usersApi.GetUsersByField(ctx, field, values)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |


# Get User Preferences

Returns all stored preference key/value pairs for the specified user. Optionally filter to a single preference by name.
Moodle method: `core_user_get_user_preferences`

```go
GetUserPreferences(
    ctx context.Context,
    userid int,
    name *string) (
    models.ApiResponse[models.UserPreferencesResponse],
    error)
```

## Authentication

This endpoint requires [BearerAuth](../../doc/auth/oauth-2-bearer-token.md)

## Parameters

| Parameter | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userid` | `int` | Query, Required | ID of the user whose preferences to retrieve. |
| `name` | `*string` | Query, Optional | Specific preference name to retrieve. Omit to retrieve all preferences. |

## Response Type

**200**: User preferences list and optional warnings.

This method returns an [`ApiResponse`](../../doc/api-response.md) instance. The `Data` property of this instance returns the response data which is of type [models.UserPreferencesResponse](../../doc/models/user-preferences-response.md).

## Example Usage

```go
ctx := context.Background()

userid := 44

apiResponse, err := usersApi.GetUserPreferences(ctx, userid, nil)
if err != nil {
    switch typedErr := err.(type) {
        case *errors.MoodleError:
            log.Fatalln("MoodleErrorException: ", typedErr)
        default:
            log.Fatalln(err)
    }
} else {
    // Printing the result and response
    fmt.Println(apiResponse.Data)
    fmt.Println(apiResponse.Response.StatusCode)
}
```

## Errors

| HTTP Status Code | Error Description | Exception Class |
|  --- | --- | --- |
| 400 | Bad request or Moodle exception. | [`MoodleErrorException`](../../doc/models/moodle-error-exception.md) |

