
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `Id` |
| `Idnumber` |
| `Username` |
| `Email` |

## Example

```go
package main

import (
    "nustLmsApi/models"
)

func main() {
    userProfileField := models.UserProfileField_Id

}
```

