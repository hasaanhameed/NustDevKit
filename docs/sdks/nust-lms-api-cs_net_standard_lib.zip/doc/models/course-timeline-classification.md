
# Course Timeline Classification

Timeline classification filter for enrolled courses.

## Enumeration

`CourseTimelineClassification`

## Fields

| Name |
|  --- |
| `All` |
| `Inprogress` |
| `Past` |
| `Future` |
| `Favourite` |
| `Hidden` |
| `Allincludinghidden` |

## Example

```csharp
using NustLmsApi.Standard.Models;

CourseTimelineClassification courseTimelineClassification = CourseTimelineClassification.Future;
```

