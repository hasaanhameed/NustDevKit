
# User Profile Field

User profile field to match against when searching for users.

## Enumeration

`UserProfileField`

## Fields

| Name |
|  --- |
| `Id` |
| `Idnumber` |
| `Username` |
| `Email` |

## Example

```csharp
using NustLmsApi.Standard.Models;

UserProfileField userProfileField = UserProfileField.Id;
```

